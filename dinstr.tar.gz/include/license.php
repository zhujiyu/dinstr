<?
echo "pMail(Public Mail System)";
echo "社交化的协同服务/办公系统";
echo "@copyright 保留一切版权";
?>
